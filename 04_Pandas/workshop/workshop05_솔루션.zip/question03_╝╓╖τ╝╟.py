import pandas as pd
import numpy as np

df = pd.read_csv('./data/employee_sample.csv', index_col=0)
print(df)
s = pd.Series(data=[25, 30, 40, 50, 35, 36, 44],
              index=['Aria', 'Niko', 'Tom', 'Zach', 'Penelope', 'Sofia', 'Dean'])
df['AGE'] = s
df['BONUS'] = 0
df_orig = df.copy()
df.loc[df['YEARS EXPERIENCE'] > 10, 'BONUS'] = 10000
print(df)
df['TOTAL SALARY'] = df['SALARY'] * 1.1 + df['BONUS']
df['TOTAL SALARY'] = df['TOTAL SALARY'].astype(np.int64)
print(df)

# 다음과 같이 구현 가능
# df['TOTAL SALARY'] = (df['SALARY'] * 1.1 + df['BONUS']).astype(np.int64)
# df.loc[:, 'TOTAL SALARY'] = (df['SALARY'] * 1.1 + df['BONUS']).astype(np.int64)
# print(df)
