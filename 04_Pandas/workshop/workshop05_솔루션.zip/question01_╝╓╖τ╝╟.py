import pandas as pd
import numpy as np

df = pd.read_csv('./data/employee_sample.csv', index_col=0)
print(df)
s = pd.Series(data=[25, 30, 40, 50, 35, 36, 44],
              index=['Aria', 'Niko', 'Tom', 'Zach', 'Penelope', 'Sofia', 'Dean'])
df['AGE'] = s
print(df)