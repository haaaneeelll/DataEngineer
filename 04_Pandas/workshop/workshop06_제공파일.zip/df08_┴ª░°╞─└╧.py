

import numpy as np
import pandas as pd
from datetime import datetime

sp500 = pd.read_csv("./data/sp500.csv",
                    index_col='Symbol',
                    usecols=[0, 2, 3, 7])

### 코드 구현 ######


### 코드 구현 ######



