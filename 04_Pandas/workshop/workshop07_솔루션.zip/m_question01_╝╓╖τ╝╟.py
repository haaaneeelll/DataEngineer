#https://www.shanelynn.ie/merge-join-dataframes-python-pandas-index-1
import pandas as pd
import numpy as np

user_usage = pd.read_csv("./data/user_usage.csv")
user_device = pd.read_csv("./data/user_device.csv")
devices = pd.read_csv("./data/android_devices.csv")

print("user_usage 데이터프레임: \n", user_usage)
print("user_device 데이터프레임: \n",user_device)
print("devices 데이터프레임: \n",devices)
devices.rename(columns={"Retail Branding": "manufacturer"}, inplace=True)
result = pd.merge(user_usage,
                 user_device[['use_id', 'platform', 'device']],
                 on='use_id')
print(result.head())
print(devices.head())

