
import pandas as pd
import numpy as np

user_usage = pd.read_csv("./data/user_usage.csv")
user_device = pd.read_csv("./data/user_device.csv")
devices = pd.read_csv("./data/android_devices.csv")


print("user_usage 데이터프레임: \n", user_usage)
print("user_device 데이터프레임: \n",user_device)
print("devices 데이터프레임: \n",devices)

### 코드 구현 ######


### 코드 구현 ######